package data;

public class HealthyBurger extends Hamburger {


    public HealthyBurger(int id, String name, double price, String meat) {
        super(id, name, price, meat, "Brown Rye Bread");
    }
}